package com.company.hrms.employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.domain.*;
import java.util.*;
public interface EmployeeRepository extends JpaRepository<Employee,UUID> {
    Page<Employee> findAllByOrderByCreatedAtDesc(Pageable pageable);
    boolean existsByEmployeeNumberIgnoreCase(String employeeNumber);
    boolean existsByWorkEmailIgnoreCase(String workEmail);
}
