package com.company.hrms.bootstrap;

import com.company.hrms.organization.*;
import com.company.hrms.bootstrap.RoleLookup;
import com.company.hrms.user.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.util.StringUtils;
import java.util.UUID;

@Configuration
public class InitialDataConfig {
    @Bean ApplicationRunner initialize(OrganizationRepository organizations, UserAccountRepository users, PasswordEncoder encoder, RoleLookup roleLookup,
        @Value("${COMPANY_NAME:Your Company}") String companyName,
        @Value("${ADMIN_USERNAME:}") String adminUsername,
        @Value("${ADMIN_PASSWORD:}") String adminPassword,
        @Value("${ADMIN_EMAIL:}") String adminEmail) {
        return args -> {
            if (!StringUtils.hasText(adminUsername) || !StringUtils.hasText(adminPassword) || !StringUtils.hasText(adminEmail)) {
                throw new IllegalStateException("Set ADMIN_USERNAME, ADMIN_PASSWORD and ADMIN_EMAIL environment variables before starting HRMS.");
            }
            if (adminPassword.length() < 14) throw new IllegalStateException("ADMIN_PASSWORD must be at least 14 characters long.");
            Organization org = organizations.findAll().stream().findFirst().orElseGet(() -> organizations.save(new Organization(UUID.randomUUID(),companyName)));
            if (!users.existsByUsernameIgnoreCase(adminUsername)) {
                Role role = roleLookup.findSuperAdmin();
                UserAccount account = UserAccountFactory.create(org,adminUsername,adminEmail,encoder.encode(adminPassword),role);
                users.save(account);
            }
        };
    }
}
