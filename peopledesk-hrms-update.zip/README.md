# PeopleDesk HRMS

Spring Boot 3.5.7, Java 21, Thymeleaf, Bootstrap 5, PostgreSQL and Flyway.

## Included in this update

The supplied Phase 1 application has been extended with the first HR operations modules:

- **Attendance:** HR can create daily employee attendance records, record check-in/check-out times, select a status, filter records by date, and see the day's present count on the dashboard.
- **Leave management:** HR can submit a leave request for an employee, review pending requests, approve or reject them, and add a reviewer comment.
- **Company holidays:** HR can add and delete company holidays; duplicate dates are prevented per organization.
- **Dashboard:** displays employee count, department count, present-today count, and pending leave-request count.
- **Navigation and authorization:** the new modules are linked in the navbar and restricted to `SUPER_ADMIN`, `HR_ADMIN`, and `HR_MANAGER`.

Existing login, registration approvals, departments, and employee creation/listing are retained.

## Important current scope

This is an incremental HRMS build, not yet the complete product. The leave screen is currently HR-managed: it does not yet provide employee self-service leave submission, leave balances, accrual rules, or payroll integration. Attendance is manually entered by HR; biometric/device integrations, employee self check-in, shift rules, overtime, and payroll calculations are not included yet. Employee edit/profile/deactivation workflows, designation management, payroll, recruitment, performance, document management, and advanced reports remain future modules.

The current application bootstraps one organization by selecting the first organization in the database, matching the existing Phase 1 design. Organization-scoped multi-tenancy needs a separate hardening pass before multiple companies share one installation.

## Database update

A new Flyway migration is included:

`src/main/resources/db/migration/V3__hr_operations.sql`

On the next normal Spring Boot startup, Flyway should apply V3 automatically. Existing V1 and V2 migrations are not modified. Do not delete or recreate `hrms_db`.

Before upgrading, take a PostgreSQL backup:

```powershell
pg_dump -U hrms_user -h localhost -d hrms_db -F c -f hrms_db_before_v3.backup
```

## Run on Windows

From the project root:

```powershell
$env:ADMIN_RESET_PASSWORD = "false"
.\mvnw.cmd clean package
.\mvnw.cmd spring-boot:run
```

If this ZIP does not contain the Maven wrapper scripts, run the project with an installed Maven executable:

```powershell
mvn clean package
mvn spring-boot:run
```

Use your existing `DB_URL`, `DB_USERNAME`, and `DB_PASSWORD` environment variables or the values in `application.yml`. Keep credentials outside source control.

**Important:** keep `ADMIN_RESET_PASSWORD=false` during normal operation. Setting it to `true` resets the existing admin password at every application startup while the flag remains enabled.

## Manual smoke test

1. Sign in with your existing administrator account.
2. Open **Attendance**. Select an employee, today's date, a status, and optionally check-in/check-out times. Save and confirm the record appears in the date list.
3. Try to add attendance again for the same employee/date; the duplicate should be rejected.
4. Open **Leave**. Submit a future-dated request for an employee, then approve or reject it and confirm the status changes.
5. Open **Holidays**. Add a holiday, confirm it appears, then delete it. Try adding another holiday on the same date; it should be rejected.
6. Return to the dashboard and verify the present-today and pending-leave counters.

## Security and operational notes

- All POST forms include Spring Security CSRF tokens.
- The new routes require an HR-capable role.
- Use HTTPS in production and set secure session cookies behind a correctly configured TLS-terminating proxy.
- Before production use, add automated integration tests, organization-scoped repository queries, audit events for attendance/leave/holiday changes, and explicit data-retention/back-up procedures.
