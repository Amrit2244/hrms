package com.company.hrms.registration;

import com.company.hrms.bootstrap.RoleLookup;
import com.company.hrms.bootstrap.UserAccountFactory;
import com.company.hrms.employee.Employee;
import com.company.hrms.employee.EmployeeRepository;
import com.company.hrms.organization.Organization;
import com.company.hrms.organization.OrganizationRepository;
import com.company.hrms.user.UserAccountRepository;
import jakarta.transaction.Transactional;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.UUID;

@Service
public class RegistrationService {
    private final RegistrationRequestRepository requests;
    private final UserAccountRepository users;
    private final OrganizationRepository organizations;
    private final EmployeeRepository employees;
    private final RoleLookup roles;
    private final PasswordEncoder passwordEncoder;

    public RegistrationService(RegistrationRequestRepository requests, UserAccountRepository users,
                               OrganizationRepository organizations, EmployeeRepository employees,
                               RoleLookup roles, PasswordEncoder passwordEncoder) {
        this.requests = requests;
        this.users = users;
        this.organizations = organizations;
        this.employees = employees;
        this.roles = roles;
        this.passwordEncoder = passwordEncoder;
    }

    @Transactional
    public void submit(RegistrationForm form) {
        String username = form.username.trim();
        String email = form.email.trim().toLowerCase();

        if (users.existsByUsernameIgnoreCase(username)
                || requests.existsByUsernameIgnoreCaseAndStatus(username, RegistrationStatus.PENDING)) {
            throw new RegistrationConflictException("That username is already registered or awaiting approval.");
        }
        if (users.existsByEmailIgnoreCase(email)
                || requests.existsByEmailIgnoreCaseAndStatus(email, RegistrationStatus.PENDING)) {
            throw new RegistrationConflictException("That email address is already registered or awaiting approval.");
        }
        if (form.password.getBytes(StandardCharsets.UTF_8).length > 72) {
            throw new RegistrationConflictException("Password must be no more than 72 UTF-8 bytes.");
        }

        Organization organization = organizations.findAll().stream().findFirst()
                .orElseThrow(() -> new IllegalStateException("The company has not been initialized yet."));

        RegistrationRequest request = new RegistrationRequest(
                UUID.randomUUID(), organization, username, email,
                passwordEncoder.encode(form.password), form.firstName.trim(), form.lastName.trim(),
                StringUtils.hasText(form.phoneNumber) ? form.phoneNumber.trim() : null);
        requests.save(request);
    }

    @Transactional
    public void approve(UUID requestId, String reviewer) {
        RegistrationRequest request = requests.findById(requestId)
                .orElseThrow(() -> new IllegalArgumentException("Registration request was not found."));
        ensurePending(request);

        if (users.existsByUsernameIgnoreCase(request.getUsername())) {
            throw new RegistrationConflictException("The username is already in use. Reject this request and ask the employee to register with another username.");
        }
        if (users.existsByEmailIgnoreCase(request.getEmail())) {
            throw new RegistrationConflictException("The email address is already in use by another account.");
        }

        // If HR already created this employee in the directory, reuse that record.
        if (employees.findByOrganization_IdAndWorkEmailIgnoreCase(
                request.getOrganization().getId(), request.getEmail()).isEmpty()) {
            String employeeNumber = "SELF-" + UUID.randomUUID().toString().substring(0, 12).toUpperCase();
            employees.save(new Employee(UUID.randomUUID(), request.getOrganization(), null,
                    employeeNumber, request.getFirstName(), request.getLastName(), request.getEmail(),
                    request.getPhoneNumber(), null, null));
        }

        users.save(UserAccountFactory.create(request.getOrganization(), request.getUsername(),
                request.getEmail(), request.getPasswordHash(), roles.findEmployee()));
        request.approve(reviewer);
    }

    @Transactional
    public void reject(UUID requestId, String reviewer) {
        RegistrationRequest request = requests.findById(requestId)
                .orElseThrow(() -> new IllegalArgumentException("Registration request was not found."));
        ensurePending(request);
        request.reject(reviewer);
    }

    private void ensurePending(RegistrationRequest request) {
        if (request.getStatus() != RegistrationStatus.PENDING) {
            throw new IllegalStateException("This registration request has already been reviewed.");
        }
    }

    public static class RegistrationForm {
        @jakarta.validation.constraints.NotBlank
        @jakarta.validation.constraints.Size(max = 80)
        public String firstName;

        @jakarta.validation.constraints.NotBlank
        @jakarta.validation.constraints.Size(max = 80)
        public String lastName;

        @jakarta.validation.constraints.NotBlank
        @jakarta.validation.constraints.Email
        @jakarta.validation.constraints.Size(max = 160)
        public String email;

        @jakarta.validation.constraints.Size(max = 30)
        public String phoneNumber;

        @jakarta.validation.constraints.NotBlank
        @jakarta.validation.constraints.Pattern(regexp = "[A-Za-z0-9._-]{4,40}",
                message = "Use 4–40 letters, numbers, dots, underscores or hyphens.")
        public String username;

        @jakarta.validation.constraints.NotBlank
        @jakarta.validation.constraints.Size(min = 12, max = 72,
                message = "Password must contain at least 12 characters and no more than 72 characters.")
        public String password;

        @jakarta.validation.constraints.NotBlank
        public String confirmPassword;
    }

    public static class RegistrationConflictException extends RuntimeException {
        public RegistrationConflictException(String message) { super(message); }
    }
}
